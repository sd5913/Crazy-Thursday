# 喂食游戏：54 个独立物件与护士台词

## 文件结构

- `png/`：54 张独立 RGBA 透明 PNG，统一为 768×768，居中留白。
- `metadata/catalogue.json`：技术接入清单。
- `metadata/catalogue.csv`：可用表格软件查看的相同数据。
- `metadata/dialogue.md`：完整中英台词对照。
- `metadata/alpha-check.json`：透明通道及边界检查记录。
- `previews/`：全部物件叠在深绿、米白背景上的检查图。

## 编号对应

001–024 对应第一批 24 个物件；025–039 对应第二批总览的 01–15；040–054 对应第二批总览的 16–30。本包不包含更早的另外 12 个物件。

每个 JSON 条目的 `file` 是相对于包根目录的 PNG 路径，`line` 是护士英文台词，`line_zh` 是中文释义。`id` 是稳定英文标识。`edible` 的 true/false 是建议分类；null 表示猎奇食品尚待组员决定判定，不可直接把 null 当作 false。这些分类没有写入现有游戏逻辑。

## 制作与限制

使用内置图像编辑工具，针对三张已有总览做背景提取：保持原物件顺序、位置、形状、配色和材质；去掉纯色背景、编号及地面投影；输出真实透明通道。随后按原网格拆分、测量 Alpha 边界并统一居中到 768×768。图像编辑可能改变部分细节，不能视为逐像素无损抠图；768×768 是交付画布尺寸，不表示恢复了总览中原本不存在的细节。

处理提示词要点：Background extraction ONLY. Preserve exact grid positions, object shapes, colours, textures and camera angles. Remove background, all numbers and cast shadows. Genuine transparent alpha; clean natural antialiased silhouettes; preserve thin edges and internal gaps. No redesign, new objects, labels, floor or checkerboard.

深浅背景预览用于检查透明效果，不是游戏素材。原始参考保留，未修改 GitHub 或游戏代码。

边界清理：拆分时扩大取样范围，并保留主物件的连通透明轮廓，移除相邻物件碎片；检查图已重新生成。
