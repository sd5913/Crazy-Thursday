# 54 objects and nurse dialogue

编号 001–024 对应第一张总览 01–24；025–039 对应第二张 01–15；040–054 对应第三张 16–30。edible=null 表示猎奇食物的游戏判定需要组员决定，不应直接当作 false。

|编号|文件|物件|英文台词|中文释义|
|---|---|---|---|---|
|1|png/001-fried-egg.png|荷包蛋|Sunny side up. Someone here should be.|至少它是阳光向上的。|
|2|png/002-salmon-sushi.png|三文鱼寿司|Fresh from the kitchen. That's all I can confirm.|厨房刚送来的。我只能确认这些。|
|3|png/003-shrimp.png|虾仁|We removed the shell. Our care is comprehensive.|壳剥了，我们的护理很周到。|
|4|png/004-meatball.png|肉丸|The ingredients are confidential.|配料属于保密信息。|
|5|png/005-chicken-nugget.png|鸡块|Shaped like food. A promising start.|看起来像食物，是个好兆头。|
|6|png/006-dumpling.png|饺子|Your next surprise comes wrapped.|下一个惊喜还包着皮。|
|7|png/007-mushroom.png|蘑菇|The kitchen seemed confident.|厨房的人看起来挺有把握。|
|8|png/008-carrot.png|胡萝卜块|Good for your eyesight. You may regret that.|对视力好。你可能会后悔看得太清楚。|
|9|png/009-banana.png|香蕉片|We sliced it. Please acknowledge the effort.|我们还切片了，请认可这份用心。|
|10|png/010-strawberry.png|草莓|A little sweetness before the next procedure.|下一个流程前，先给你点甜头。|
|11|png/011-cookie.png|曲奇|A reward for your continued cooperation.|奖励你持续配合治疗。|
|12|png/012-cheese.png|芝士块|Aged beautifully. Unlike this hospital.|陈年风味。比这医院老得体面。|
|13|png/013-eraser.png|橡皮|Let's erase that last medical opinion.|把刚才那个诊断擦掉吧。|
|14|png/014-button.png|纽扣|This should help you keep it together.|帮你把自己扣紧一点。|
|15|png/015-bottle-cap.png|瓶盖|Your meal appears to be sealed.|你的餐看起来还没开封。|
|16|png/016-key.png|钥匙|The key to recovery. Open wide.|康复的钥匙。张嘴。|
|17|png/017-battery.png|电池|You look like you could use some energy.|你看起来需要补充电量。|
|18|png/018-clothespin.png|衣夹|For when you can't keep your mouth shut.|给管不住嘴的时候用。|
|19|png/019-die.png|骰子|We've updated our diagnostic equipment.|我们升级了诊断设备。|
|20|png/020-screw.png|螺丝|You did seem a little loose.|你看起来确实有点松。|
|21|png/021-soap.png|巧克力形肥皂|Clean eating. Literally.|洁净饮食。字面意义上的。|
|22|png/022-toothpaste.png|牙膏|Dinner and dental care. We're saving time.|吃饭刷牙一起办，节约时间。|
|23|png/023-candy-eraser.png|糖果形橡皮|All the colour. None of the nutritional obligations.|颜色到位，营养概不负责。|
|24|png/024-cork.png|饼干形软木片|An excellent pairing with whatever's in your IV.|和你吊瓶里的东西应该很搭。|
|25|png/025-rice-ball.png|海苔饭团|A balanced meal. Structurally speaking.|很均衡的一餐。从结构上说。|
|26|png/026-rolled-omelette.png|玉子烧|Your breakfast has been neatly filed.|你的早餐已经整理归档了。|
|27|png/027-corn.png|玉米段|We counted the kernels. That's today's assessment.|玉米粒数过了。今天的检查结束。|
|28|png/028-cream-puff.png|奶油泡芙|A soft centre. We had one once.|内心柔软。我们以前也是。|
|29|png/029-salmon-cube.png|煎三文鱼块|Pink is a reassuring colour. Usually.|粉色让人安心。通常如此。|
|30|png/030-peach.png|半颗桃子|We left the stone. Budget cuts.|核没去。经费削减。|
|31|png/031-olive-jelly.png|橄榄果冻|Dessert has developed a savoury opinion.|甜点有了自己的咸味主张。|
|32|png/032-sardine-tart.png|沙丁鱼挞|The bakery and the aquarium share a supplier.|面包房和水族馆共用供应商。|
|33|png/033-wasabi-macaron.png|芥末马卡龙|A small gift for your sinuses.|给鼻腔准备的一份小礼物。|
|34|png/034-blue-noodles.png|蓝色面条|The colour was approved. The rest is pending.|颜色审批通过了。其他还在等。|
|35|png/035-pickle-icecream.png|酸黄瓜冰淇淋|Sweet and sour. Like your relationship with us.|酸甜交织。就像你和我们的关系。|
|36|png/036-candied-garlic.png|糖衣大蒜|Your visitors will understand the message.|探病的人会明白这个暗示。|
|37|png/037-squidink-doughnut.png|墨鱼汁甜甜圈|The hole is the lightest part.|中间那个洞是最清淡的部分。|
|38|png/038-cheese-pear.png|芝士夹心梨|The fruit has requested a dairy consultation.|水果申请了乳制品会诊。|
|39|png/039-broccoli-puff.png|西兰花泡芙|We found a way to disappoint both departments.|面包房和蔬菜部都不满意。|
|40|png/040-egg-tart.png|煎蛋挞|Two breakfasts. One administrative error.|两份早餐。一次行政失误。|
|41|png/041-octopus-sausage.png|章鱼香肠|It has more mobility than you do.|它的活动能力比你强。|
|42|png/042-chocolate-tofu.png|巧克力豆腐|Dessert is still deciding what it wants to be.|甜点还没决定长大想做什么。|
|43|png/043-cabbage-cake.png|紫甘蓝千层蛋糕|A salad with excellent presentation skills.|很擅长包装自己的沙拉。|
|44|png/044-shrimp-jelly.png|虾仁果冻|Your seafood has been suspended pending review.|你的海鲜已被暂停，等候审查。|
|45|png/045-fish-bun.png|鱼头造型包子|It looks concerned. How unprofessional.|它看起来很担忧。真不专业。|
|46|png/046-kiwi-sushi.png|奇异果寿司|The chef has stopped recognising borders.|厨师已经不再承认食物的边界。|
|47|png/047-chili-chocolate.png|辣椒巧克力|For patients who find dessert too comforting.|专为觉得甜点太安慰人的病人准备。|
|48|png/048-nori-marshmallow.png|海苔棉花糖|We put dessert in a little uniform.|我们给甜点穿了件小制服。|
|49|png/049-spaghetti-cube.png|方块意面肉丸|We compressed your lunch to improve efficiency.|为提高效率，我们压缩了你的午餐。|
|50|png/050-tooth-mochi.png|牙齿形麻薯|A replacement tooth. Results may be chewy.|替补牙齿。使用效果可能有点黏。|
|51|png/051-lychee-eyeball.png|荔枝眼球糖|Finally, a meal that maintains eye contact.|终于有一餐愿意保持眼神交流了。|
|52|png/052-mushroom-flan.png|蘑菇布丁|The dessert trolley took a wrong turn.|甜点推车拐错了弯。|
|53|png/053-banana-shrimp.png|香蕉虾卷|Neither ingredient signed off on this.|两种食材都没有签字同意。|
|54|png/054-eel-eclair.png|鳗鱼闪电泡芙|The pastry chef would like to remain anonymous.|甜点师希望保持匿名。|
