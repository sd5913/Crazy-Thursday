# 50 个干净、奇特的游戏异物：修正版

画风回到最初仙人掌、海绵和积木那组：半写实、略低多边形、自然克制配色、简单材质与中性光照。通过离谱搭配和非食用材质制造笑点，取消霉菌、虫子、头发、腐败及脏黏液。沿用本批游戏异物用途，edible=false；这不代表把植物或日常食物的现实分类统一化，而是此处组合道具的游戏规则。已导出单件透明 PNG；没有修改游戏。

|编号|物件|英文护士台词|中文释义|
|---|---|---|---|
|01|仙人掌冰淇淋|A little texture with your dessert.|给甜点增加一点口感。|
|02|积木果冻|A dessert you can build on.|可以继续搭建的甜点。|
|03|海绵蛋糕|The kitchen took the name literally.|厨房按字面意思理解了。|
|04|巧克力肥皂|Clean eating. Our interpretation.|洁净饮食，我们的理解。|
|05|牙膏马卡龙|Dessert and dental care share a budget.|甜点和牙科共用预算。|
|06|软木寿司|An unusually dry finish.|收尾格外干燥。|
|07|橡皮筋面条|A flexible lunch arrangement.|灵活的午餐安排。|
|08|铅笔威化|A snack for taking notes.|适合做笔记的小点心。|
|09|纽扣饼干|This should hold things together.|这能把东西扣紧一点。|
|10|钥匙可颂|The key to a better breakfast.|更好早餐的钥匙。|
|11|骰子芝士|Lunch is now evidence-based. We roll for it.|午餐有依据了，掷骰子决定。|
|12|橡皮寿司|We can erase your previous order.|可以擦掉你的上一份订单。|
|13|羽毛球蛋白霜|A very light course.|非常轻盈的一道菜。|
|14|衣夹卷饼|A firm grip on nutrition.|牢牢夹住营养。|
|15|橡皮鸭煎蛋|The duck has declined to elaborate.|鸭子拒绝进一步说明。|
|16|拼图三明治|The missing piece of your lunch.|午餐缺失的那一块。|
|17|灯泡梨|A bright idea from catering.|餐饮部的亮点创意。|
|18|硅胶草莓|Seasonal appearance. Permanent shelf life.|季节性外观，永久保质期。|
|19|折纸馄饨|Your lunch has been carefully folded.|午餐已经仔细折好了。|
|20|蜡烛辣椒|We found another way to add heat.|我们找到了另一种加热方式。|
|21|陶瓷棉花糖|Firmly committed to being soft.|坚定地致力于柔软。|
|22|瓶盖麻薯|A sealed approach to dessert.|密封式甜点方案。|
|23|棋子蘑菇|Your next meal is a strategic decision.|下一口是战略性决策。|
|24|玻璃弹珠葡萄|Excellent presentation. Limited chewing options.|卖相很好，咀嚼选项有限。|
|25|电线甘草糖|A direct connection to lunch.|与午餐直接连线。|
|26|仙人掌饺子|A filling with clear boundaries.|边界感很强的馅料。|
|27|铁钉蝴蝶饼|The bakery has joined the hardware scheme.|面包房加入了五金计划。|
|28|螺丝香肠|Lunch has been properly fastened.|午餐已经固定好了。|
|29|齿轮华夫饼|Breakfast keeps the department running.|早餐维持着部门运转。|
|30|电池蛋糕卷|For patients running on low power.|给电量不足的病人准备的。|
|31|磁铁马卡龙|An attractive dessert option.|很有吸引力的甜点选项。|
|32|螺母甜甜圈|The doughnut has a technical background.|这个甜甜圈有技术背景。|
|33|回形针酥|We attached the snack to your file.|点心已经夹到档案上了。|
|34|弹簧面条|A remarkably resilient lunch.|韧性非凡的午餐。|
|35|拉链热狗|Please close your meal after use.|使用后请拉好午餐。|
|36|糖果肥皂|A sweet-looking misunderstanding.|看着很甜的一场误会。|
|37|塑料贝壳松露巧克力|A decorative approach to chocolate.|装饰性巧克力方案。|
|38|键帽巧克力|Press here to continue lunch.|按这里继续午餐。|
|39|芯片米饼|A smarter snack. Allegedly.|据说是更聪明的点心。|
|40|玩具车包子|Your meal has its own transport.|午餐自带交通工具。|
|41|手套奶油卷|A hands-on dessert service.|亲手服务的甜点。|
|42|泡泡膜饺子|Packed with little surprises.|包装里满是小惊喜。|
|43|锡纸巧克力块|The presentation department did most of the work.|大部分工作由包装部完成。|
|44|木头冰棍|Slow melting. Very slow.|融化很慢，非常慢。|
|45|陶瓷橘子|A fruit with a glazed expression.|表情上了釉的水果。|
|46|多肉纸杯蛋糕|Dessert now comes with a care schedule.|甜点附带养护日程。|
|47|积木玉米|Every kernel is replaceable.|每粒玉米都能更换。|
|48|茶包麻薯|Tea has submitted a request to be dessert.|茶提交了成为甜点的申请。|
|49|蜡笔胡萝卜|A colourful contribution from the art department.|美术部的缤纷贡献。|
|50|刷毛寿司|The kitchen sent its finest brushwork.|厨房送来了最精细的刷工。|

